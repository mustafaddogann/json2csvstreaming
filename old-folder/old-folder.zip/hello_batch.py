print("Hello from ADF Custom Activity! The batch pool is working.", flush=True)
